import React from 'react';
import './App.css';

import Perfil from './components/Perfil';

function App(){
  return(
    <Perfil/>
  )
}

export default App;





